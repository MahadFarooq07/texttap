// src/lib/storage.js
var DB_NAME = "texttap-captures";
var MAX_AGE = 30 * 60 * 1e3;
function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore("captures", { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function transact(mode, action) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("captures", mode);
    let result;
    tx.oncomplete = () => {
      db.close();
      resolve(result);
    };
    tx.onerror = tx.onabort = () => {
      db.close();
      reject(tx.error || new Error("Local capture storage failed."));
    };
    action(tx.objectStore("captures"), (value) => {
      result = value;
    });
  });
}
async function pruneCaptures(now = Date.now()) {
  return transact("readwrite", (store) => {
    const request = store.openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      if (now - cursor.value.createdAt > MAX_AGE) cursor.delete();
      cursor.continue();
    };
  });
}
async function saveCapture(capture) {
  await pruneCaptures();
  return transact("readwrite", (store) => store.put(capture));
}
async function deleteCapture(id) {
  return transact("readwrite", (store) => store.delete(id));
}

// src/lib/geometry.js
function validateRegion(region) {
  if (!region || !["x", "y", "width", "height", "viewportWidth", "viewportHeight"].every(
    (key) => Number.isFinite(region[key])
  ))
    return false;
  return region.x >= 0 && region.y >= 0 && region.width >= 5 && region.height >= 5 && region.viewportWidth > 0 && region.viewportHeight > 0 && region.x + region.width <= region.viewportWidth + 1 && region.y + region.height <= region.viewportHeight + 1;
}

// src/background.js
var capturing = false;
var extensionOrigin = chrome.runtime.getURL("");
var editorJobs = /* @__PURE__ */ new Map();
function isExtensionPage(sender) {
  return sender.id === chrome.runtime.id && typeof sender.url === "string" && sender.url.startsWith(extensionOrigin) && !sender.tab?.url?.startsWith("http");
}
async function currentTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });
  if (!tab?.id || !Number.isInteger(tab.windowId))
    throw new Error("Open a browser tab first.");
  return tab;
}
async function assertActive(tab) {
  const [active] = await chrome.tabs.query({
    active: true,
    windowId: tab.windowId
  });
  if (active?.id !== tab.id)
    throw new Error(
      "The active tab changed. Return to the source tab and capture again."
    );
}
async function openEditor(tab, region) {
  if (capturing) throw new Error("A capture is already being prepared.");
  capturing = true;
  let id;
  try {
    await assertActive(tab);
    const image = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "png"
    });
    await assertActive(tab);
    if (image.length > 40 * 1024 * 1024)
      throw new Error(
        "This screenshot is too large. Use a smaller browser window or import a smaller image."
      );
    id = crypto.randomUUID();
    await saveCapture({ id, image, region, createdAt: Date.now() });
    const editor = await chrome.tabs.create({
      url: chrome.runtime.getURL(`editor.html?capture=${id}`),
      windowId: tab.windowId
    });
    if (editor.id) editorJobs.set(editor.id, id);
    return { ok: true };
  } catch (error) {
    if (id) await deleteCapture(id).catch(() => {
    });
    throw error;
  } finally {
    capturing = false;
  }
}
async function selectRegion(tab) {
  if (!/^https?:\/\//i.test(tab.url || "") || /^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/.test(
    tab.url || ""
  )) {
    throw new Error(
      "Chrome blocks selection on this page. Use Capture visible tab, then crop it in the editor."
    );
  }
  await assertActive(tab);
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["selection.js"]
  });
  return { ok: true };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !message || typeof message.type !== "string")
    return false;
  const regionMessage = message.type === "CAPTURE_REGION";
  if (regionMessage) {
    if (!sender.tab?.id || sender.frameId !== 0 || !validateRegion(message.region)) {
      sendResponse({ ok: false, error: "Invalid capture selection." });
      return false;
    }
  } else if (!isExtensionPage(sender)) return false;
  const supported = [
    "SELECT_REGION",
    "CAPTURE_VISIBLE",
    "OPEN_EDITOR",
    "CAPTURE_REGION"
  ];
  if (!supported.includes(message.type)) return false;
  (async () => {
    if (regionMessage) return openEditor(sender.tab, message.region);
    if (message.type === "OPEN_EDITOR") {
      await chrome.tabs.create({ url: chrome.runtime.getURL("editor.html") });
      return { ok: true };
    }
    const tab = await currentTab();
    return message.type === "SELECT_REGION" ? selectRegion(tab) : openEditor(tab, null);
  })().then(
    sendResponse,
    (error) => sendResponse({
      ok: false,
      error: error.message || "Capture failed. Please try again."
    })
  );
  return true;
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "capture-region") return;
  try {
    await selectRegion(await currentTab());
  } catch (error) {
    await chrome.tabs.create({
      url: chrome.runtime.getURL(
        `editor.html?error=${encodeURIComponent(error.message)}`
      )
    });
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  const id = editorJobs.get(tabId);
  if (id) {
    editorJobs.delete(tabId);
    void deleteCapture(id);
  }
});
chrome.runtime.onStartup.addListener(() => {
  void pruneCaptures();
});
chrome.runtime.onInstalled.addListener(() => {
  void pruneCaptures();
});
export {
  isExtensionPage
};
