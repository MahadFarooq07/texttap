"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/regenerator-runtime/runtime.js
  var require_runtime = __commonJS({
    "node_modules/regenerator-runtime/runtime.js"(exports, module) {
      var runtime = (function(exports2) {
        "use strict";
        var Op = Object.prototype;
        var hasOwn = Op.hasOwnProperty;
        var defineProperty = Object.defineProperty || function(obj, key, desc) {
          obj[key] = desc.value;
        };
        var undefined;
        var $Symbol = typeof Symbol === "function" ? Symbol : {};
        var iteratorSymbol = $Symbol.iterator || "@@iterator";
        var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
        var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
        function define(obj, key, value) {
          Object.defineProperty(obj, key, {
            value,
            enumerable: true,
            configurable: true,
            writable: true
          });
          return obj[key];
        }
        try {
          define({}, "");
        } catch (err) {
          define = function(obj, key, value) {
            return obj[key] = value;
          };
        }
        function wrap(innerFn, outerFn, self, tryLocsList) {
          var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
          var generator = Object.create(protoGenerator.prototype);
          var context = new Context(tryLocsList || []);
          defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) });
          return generator;
        }
        exports2.wrap = wrap;
        function tryCatch(fn, obj, arg) {
          try {
            return { type: "normal", arg: fn.call(obj, arg) };
          } catch (err) {
            return { type: "throw", arg: err };
          }
        }
        var GenStateSuspendedStart = "suspendedStart";
        var GenStateSuspendedYield = "suspendedYield";
        var GenStateExecuting = "executing";
        var GenStateCompleted = "completed";
        var ContinueSentinel = {};
        function Generator() {
        }
        function GeneratorFunction() {
        }
        function GeneratorFunctionPrototype() {
        }
        var IteratorPrototype = {};
        define(IteratorPrototype, iteratorSymbol, function() {
          return this;
        });
        var getProto = Object.getPrototypeOf;
        var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
        if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
          IteratorPrototype = NativeIteratorPrototype;
        }
        var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
        GeneratorFunction.prototype = GeneratorFunctionPrototype;
        defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: true });
        defineProperty(
          GeneratorFunctionPrototype,
          "constructor",
          { value: GeneratorFunction, configurable: true }
        );
        GeneratorFunction.displayName = define(
          GeneratorFunctionPrototype,
          toStringTagSymbol,
          "GeneratorFunction"
        );
        function defineIteratorMethods(prototype) {
          ["next", "throw", "return"].forEach(function(method) {
            define(prototype, method, function(arg) {
              return this._invoke(method, arg);
            });
          });
        }
        exports2.isGeneratorFunction = function(genFun) {
          var ctor = typeof genFun === "function" && genFun.constructor;
          return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
          // do is to check its .name property.
          (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
        };
        exports2.mark = function(genFun) {
          if (Object.setPrototypeOf) {
            Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
          } else {
            genFun.__proto__ = GeneratorFunctionPrototype;
            define(genFun, toStringTagSymbol, "GeneratorFunction");
          }
          genFun.prototype = Object.create(Gp);
          return genFun;
        };
        exports2.awrap = function(arg) {
          return { __await: arg };
        };
        function AsyncIterator(generator, PromiseImpl) {
          function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if (record.type === "throw") {
              reject(record.arg);
            } else {
              var result2 = record.arg;
              var value = result2.value;
              if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
                return PromiseImpl.resolve(value.__await).then(function(value2) {
                  invoke("next", value2, resolve, reject);
                }, function(err) {
                  invoke("throw", err, resolve, reject);
                });
              }
              return PromiseImpl.resolve(value).then(function(unwrapped) {
                result2.value = unwrapped;
                resolve(result2);
              }, function(error) {
                return invoke("throw", error, resolve, reject);
              });
            }
          }
          var previousPromise;
          function enqueue(method, arg) {
            function callInvokeWithMethodAndArg() {
              return new PromiseImpl(function(resolve, reject) {
                invoke(method, arg, resolve, reject);
              });
            }
            return previousPromise = // If enqueue has been called before, then we want to wait until
            // all previous Promises have been resolved before calling invoke,
            // so that results are always delivered in the correct order. If
            // enqueue has not been called before, then it is important to
            // call invoke immediately, without waiting on a callback to fire,
            // so that the async generator function has the opportunity to do
            // any necessary setup in a predictable way. This predictability
            // is why the Promise constructor synchronously invokes its
            // executor callback, and why async functions synchronously
            // execute code before the first await. Since we implement simple
            // async functions in terms of async generators, it is especially
            // important to get this right, even though it requires care.
            previousPromise ? previousPromise.then(
              callInvokeWithMethodAndArg,
              // Avoid propagating failures to Promises returned by later
              // invocations of the iterator.
              callInvokeWithMethodAndArg
            ) : callInvokeWithMethodAndArg();
          }
          defineProperty(this, "_invoke", { value: enqueue });
        }
        defineIteratorMethods(AsyncIterator.prototype);
        define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
          return this;
        });
        exports2.AsyncIterator = AsyncIterator;
        exports2.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
          if (PromiseImpl === void 0) PromiseImpl = Promise;
          var iter = new AsyncIterator(
            wrap(innerFn, outerFn, self, tryLocsList),
            PromiseImpl
          );
          return exports2.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result2) {
            return result2.done ? result2.value : iter.next();
          });
        };
        function makeInvokeMethod(innerFn, self, context) {
          var state = GenStateSuspendedStart;
          return function invoke(method, arg) {
            if (state === GenStateExecuting) {
              throw new Error("Generator is already running");
            }
            if (state === GenStateCompleted) {
              if (method === "throw") {
                throw arg;
              }
              return doneResult();
            }
            context.method = method;
            context.arg = arg;
            while (true) {
              var delegate = context.delegate;
              if (delegate) {
                var delegateResult = maybeInvokeDelegate(delegate, context);
                if (delegateResult) {
                  if (delegateResult === ContinueSentinel) continue;
                  return delegateResult;
                }
              }
              if (context.method === "next") {
                context.sent = context._sent = context.arg;
              } else if (context.method === "throw") {
                if (state === GenStateSuspendedStart) {
                  state = GenStateCompleted;
                  throw context.arg;
                }
                context.dispatchException(context.arg);
              } else if (context.method === "return") {
                context.abrupt("return", context.arg);
              }
              state = GenStateExecuting;
              var record = tryCatch(innerFn, self, context);
              if (record.type === "normal") {
                state = context.done ? GenStateCompleted : GenStateSuspendedYield;
                if (record.arg === ContinueSentinel) {
                  continue;
                }
                return {
                  value: record.arg,
                  done: context.done
                };
              } else if (record.type === "throw") {
                state = GenStateCompleted;
                context.method = "throw";
                context.arg = record.arg;
              }
            }
          };
        }
        function maybeInvokeDelegate(delegate, context) {
          var methodName = context.method;
          var method = delegate.iterator[methodName];
          if (method === undefined) {
            context.delegate = null;
            if (methodName === "throw" && delegate.iterator["return"]) {
              context.method = "return";
              context.arg = undefined;
              maybeInvokeDelegate(delegate, context);
              if (context.method === "throw") {
                return ContinueSentinel;
              }
            }
            if (methodName !== "return") {
              context.method = "throw";
              context.arg = new TypeError(
                "The iterator does not provide a '" + methodName + "' method"
              );
            }
            return ContinueSentinel;
          }
          var record = tryCatch(method, delegate.iterator, context.arg);
          if (record.type === "throw") {
            context.method = "throw";
            context.arg = record.arg;
            context.delegate = null;
            return ContinueSentinel;
          }
          var info = record.arg;
          if (!info) {
            context.method = "throw";
            context.arg = new TypeError("iterator result is not an object");
            context.delegate = null;
            return ContinueSentinel;
          }
          if (info.done) {
            context[delegate.resultName] = info.value;
            context.next = delegate.nextLoc;
            if (context.method !== "return") {
              context.method = "next";
              context.arg = undefined;
            }
          } else {
            return info;
          }
          context.delegate = null;
          return ContinueSentinel;
        }
        defineIteratorMethods(Gp);
        define(Gp, toStringTagSymbol, "Generator");
        define(Gp, iteratorSymbol, function() {
          return this;
        });
        define(Gp, "toString", function() {
          return "[object Generator]";
        });
        function pushTryEntry(locs) {
          var entry = { tryLoc: locs[0] };
          if (1 in locs) {
            entry.catchLoc = locs[1];
          }
          if (2 in locs) {
            entry.finallyLoc = locs[2];
            entry.afterLoc = locs[3];
          }
          this.tryEntries.push(entry);
        }
        function resetTryEntry(entry) {
          var record = entry.completion || {};
          record.type = "normal";
          delete record.arg;
          entry.completion = record;
        }
        function Context(tryLocsList) {
          this.tryEntries = [{ tryLoc: "root" }];
          tryLocsList.forEach(pushTryEntry, this);
          this.reset(true);
        }
        exports2.keys = function(val) {
          var object = Object(val);
          var keys = [];
          for (var key in object) {
            keys.push(key);
          }
          keys.reverse();
          return function next() {
            while (keys.length) {
              var key2 = keys.pop();
              if (key2 in object) {
                next.value = key2;
                next.done = false;
                return next;
              }
            }
            next.done = true;
            return next;
          };
        };
        function values(iterable) {
          if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) {
              return iteratorMethod.call(iterable);
            }
            if (typeof iterable.next === "function") {
              return iterable;
            }
            if (!isNaN(iterable.length)) {
              var i = -1, next = function next2() {
                while (++i < iterable.length) {
                  if (hasOwn.call(iterable, i)) {
                    next2.value = iterable[i];
                    next2.done = false;
                    return next2;
                  }
                }
                next2.value = undefined;
                next2.done = true;
                return next2;
              };
              return next.next = next;
            }
          }
          return { next: doneResult };
        }
        exports2.values = values;
        function doneResult() {
          return { value: undefined, done: true };
        }
        Context.prototype = {
          constructor: Context,
          reset: function(skipTempReset) {
            this.prev = 0;
            this.next = 0;
            this.sent = this._sent = undefined;
            this.done = false;
            this.delegate = null;
            this.method = "next";
            this.arg = undefined;
            this.tryEntries.forEach(resetTryEntry);
            if (!skipTempReset) {
              for (var name in this) {
                if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
                  this[name] = undefined;
                }
              }
            }
          },
          stop: function() {
            this.done = true;
            var rootEntry = this.tryEntries[0];
            var rootRecord = rootEntry.completion;
            if (rootRecord.type === "throw") {
              throw rootRecord.arg;
            }
            return this.rval;
          },
          dispatchException: function(exception) {
            if (this.done) {
              throw exception;
            }
            var context = this;
            function handle(loc, caught) {
              record.type = "throw";
              record.arg = exception;
              context.next = loc;
              if (caught) {
                context.method = "next";
                context.arg = undefined;
              }
              return !!caught;
            }
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              var record = entry.completion;
              if (entry.tryLoc === "root") {
                return handle("end");
              }
              if (entry.tryLoc <= this.prev) {
                var hasCatch = hasOwn.call(entry, "catchLoc");
                var hasFinally = hasOwn.call(entry, "finallyLoc");
                if (hasCatch && hasFinally) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  } else if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else if (hasCatch) {
                  if (this.prev < entry.catchLoc) {
                    return handle(entry.catchLoc, true);
                  }
                } else if (hasFinally) {
                  if (this.prev < entry.finallyLoc) {
                    return handle(entry.finallyLoc);
                  }
                } else {
                  throw new Error("try statement without catch or finally");
                }
              }
            }
          },
          abrupt: function(type, arg) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                var finallyEntry = entry;
                break;
              }
            }
            if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
              finallyEntry = null;
            }
            var record = finallyEntry ? finallyEntry.completion : {};
            record.type = type;
            record.arg = arg;
            if (finallyEntry) {
              this.method = "next";
              this.next = finallyEntry.finallyLoc;
              return ContinueSentinel;
            }
            return this.complete(record);
          },
          complete: function(record, afterLoc) {
            if (record.type === "throw") {
              throw record.arg;
            }
            if (record.type === "break" || record.type === "continue") {
              this.next = record.arg;
            } else if (record.type === "return") {
              this.rval = this.arg = record.arg;
              this.method = "return";
              this.next = "end";
            } else if (record.type === "normal" && afterLoc) {
              this.next = afterLoc;
            }
            return ContinueSentinel;
          },
          finish: function(finallyLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.finallyLoc === finallyLoc) {
                this.complete(entry.completion, entry.afterLoc);
                resetTryEntry(entry);
                return ContinueSentinel;
              }
            }
          },
          "catch": function(tryLoc) {
            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
              var entry = this.tryEntries[i];
              if (entry.tryLoc === tryLoc) {
                var record = entry.completion;
                if (record.type === "throw") {
                  var thrown = record.arg;
                  resetTryEntry(entry);
                }
                return thrown;
              }
            }
            throw new Error("illegal catch attempt");
          },
          delegateYield: function(iterable, resultName, nextLoc) {
            this.delegate = {
              iterator: values(iterable),
              resultName,
              nextLoc
            };
            if (this.method === "next") {
              this.arg = undefined;
            }
            return ContinueSentinel;
          }
        };
        return exports2;
      })(
        // If this script is executing as a CommonJS module, use module.exports
        // as the regeneratorRuntime namespace. Otherwise create a new empty
        // object. Either way, the resulting object will be used to initialize
        // the regeneratorRuntime variable at the top of this file.
        typeof module === "object" ? module.exports : {}
      );
      try {
        regeneratorRuntime = runtime;
      } catch (accidentalStrictMode) {
        if (typeof globalThis === "object") {
          globalThis.regeneratorRuntime = runtime;
        } else {
          Function("r", "regeneratorRuntime = r")(runtime);
        }
      }
    }
  });

  // node_modules/tesseract.js/src/utils/getId.js
  var require_getId = __commonJS({
    "node_modules/tesseract.js/src/utils/getId.js"(exports, module) {
      "use strict";
      module.exports = (prefix, cnt) => `${prefix}-${cnt}-${Math.random().toString(16).slice(3, 8)}`;
    }
  });

  // node_modules/tesseract.js/src/createJob.js
  var require_createJob = __commonJS({
    "node_modules/tesseract.js/src/createJob.js"(exports, module) {
      "use strict";
      var getId = require_getId();
      var jobCounter = 0;
      module.exports = ({
        id: _id,
        action,
        payload = {}
      }) => {
        let id = _id;
        if (typeof id === "undefined") {
          id = getId("Job", jobCounter);
          jobCounter += 1;
        }
        return {
          id,
          action,
          payload
        };
      };
    }
  });

  // node_modules/tesseract.js/src/utils/log.js
  var require_log = __commonJS({
    "node_modules/tesseract.js/src/utils/log.js"(exports) {
      "use strict";
      var logging = false;
      exports.logging = logging;
      exports.setLogging = (_logging) => {
        logging = _logging;
      };
      exports.log = (...args) => logging ? console.log.apply(exports, args) : null;
    }
  });

  // node_modules/tesseract.js/src/createScheduler.js
  var require_createScheduler = __commonJS({
    "node_modules/tesseract.js/src/createScheduler.js"(exports, module) {
      "use strict";
      var createJob = require_createJob();
      var { log } = require_log();
      var getId = require_getId();
      var schedulerCounter = 0;
      module.exports = () => {
        const id = getId("Scheduler", schedulerCounter);
        const workers = {};
        const runningWorkers = {};
        let jobQueue = [];
        schedulerCounter += 1;
        const getQueueLen = () => jobQueue.length;
        const getNumWorkers = () => Object.keys(workers).length;
        const dequeue = () => {
          if (jobQueue.length !== 0) {
            const wIds = Object.keys(workers);
            for (let i = 0; i < wIds.length; i += 1) {
              if (typeof runningWorkers[wIds[i]] === "undefined") {
                jobQueue[0](workers[wIds[i]]);
                break;
              }
            }
          }
        };
        const queue = (action, payload) => new Promise((resolve, reject) => {
          const job = createJob({ action, payload });
          jobQueue.push(async (w) => {
            jobQueue.shift();
            runningWorkers[w.id] = job;
            try {
              resolve(await w[action].apply(exports, [...payload, job.id]));
            } catch (err) {
              reject(err);
            } finally {
              delete runningWorkers[w.id];
              dequeue();
            }
          });
          log(`[${id}]: Add ${job.id} to JobQueue`);
          log(`[${id}]: JobQueue length=${jobQueue.length}`);
          dequeue();
        });
        const addWorker = (w) => {
          workers[w.id] = w;
          log(`[${id}]: Add ${w.id}`);
          log(`[${id}]: Number of workers=${getNumWorkers()}`);
          dequeue();
          return w.id;
        };
        const addJob = async (action, ...payload) => {
          if (getNumWorkers() === 0) {
            throw Error(`[${id}]: You need to have at least one worker before adding jobs`);
          }
          return queue(action, payload);
        };
        const terminate = async () => {
          Object.keys(workers).forEach(async (wid) => {
            await workers[wid].terminate();
          });
          jobQueue = [];
        };
        return {
          addWorker,
          addJob,
          terminate,
          getQueueLen,
          getNumWorkers
        };
      };
    }
  });

  // node_modules/tesseract.js/src/utils/getEnvironment.js
  var require_getEnvironment = __commonJS({
    "node_modules/tesseract.js/src/utils/getEnvironment.js"(exports, module) {
      "use strict";
      module.exports = (key) => {
        const env = {};
        if (typeof WorkerGlobalScope !== "undefined") {
          env.type = "webworker";
        } else if (typeof document === "object") {
          env.type = "browser";
        } else if (typeof process === "object" && typeof __require === "function") {
          env.type = "node";
        }
        if (typeof key === "undefined") {
          return env;
        }
        return env[key];
      };
    }
  });

  // node_modules/tesseract.js/src/utils/resolvePaths.js
  var require_resolvePaths = __commonJS({
    "node_modules/tesseract.js/src/utils/resolvePaths.js"(exports, module) {
      "use strict";
      var isBrowser = require_getEnvironment()("type") === "browser";
      var resolveURL = isBrowser ? (s) => new URL(s, window.location.href).href : (s) => s;
      module.exports = (options) => {
        const opts = { ...options };
        ["corePath", "workerPath", "langPath"].forEach((key) => {
          if (options[key]) {
            opts[key] = resolveURL(opts[key]);
          }
        });
        return opts;
      };
    }
  });

  // node_modules/tesseract.js/src/constants/OEM.js
  var require_OEM = __commonJS({
    "node_modules/tesseract.js/src/constants/OEM.js"(exports, module) {
      "use strict";
      module.exports = {
        TESSERACT_ONLY: 0,
        LSTM_ONLY: 1,
        TESSERACT_LSTM_COMBINED: 2,
        DEFAULT: 3
      };
    }
  });

  // node_modules/tesseract.js/package.json
  var require_package = __commonJS({
    "node_modules/tesseract.js/package.json"(exports, module) {
      module.exports = {
        name: "tesseract.js",
        version: "7.0.0",
        description: "Pure Javascript Multilingual OCR",
        main: "src/index.js",
        type: "commonjs",
        types: "src/index.d.ts",
        unpkg: "dist/tesseract.min.js",
        jsdelivr: "dist/tesseract.min.js",
        scripts: {
          start: "node scripts/server.js",
          build: "rimraf dist && webpack --config scripts/webpack.config.prod.js && rollup -c scripts/rollup.esm.mjs",
          "profile:tesseract": "webpack-bundle-analyzer dist/tesseract-stats.json",
          "profile:worker": "webpack-bundle-analyzer dist/worker-stats.json",
          prepublishOnly: "npm run build",
          wait: "rimraf dist && wait-on http://localhost:3000/dist/tesseract.min.js",
          test: "npm-run-all -p -r start test:all",
          "test:all": "npm-run-all wait test:browser test:node:all",
          "test:browser": "karma start karma.conf.js",
          "test:node": "nyc mocha --exit --bail --require ./scripts/test-helper.mjs",
          "test:node:all": "npm run test:node -- ./tests/*.test.mjs",
          lint: "eslint src",
          "lint:fix": "eslint --fix src",
          postinstall: "opencollective-postinstall || true"
        },
        browser: {
          "./src/worker/node/index.js": "./src/worker/browser/index.js"
        },
        author: "",
        contributors: [
          "jeromewu"
        ],
        license: "Apache-2.0",
        devDependencies: {
          "@babel/core": "^7.21.4",
          "@babel/eslint-parser": "^7.21.3",
          "@babel/preset-env": "^7.21.4",
          "@rollup/plugin-commonjs": "^24.1.0",
          acorn: "^8.8.2",
          "babel-loader": "^9.1.2",
          buffer: "^6.0.3",
          cors: "^2.8.5",
          eslint: "^7.32.0",
          "eslint-config-airbnb-base": "^14.2.1",
          "eslint-plugin-import": "^2.27.5",
          "expect.js": "^0.3.1",
          express: "^4.18.2",
          mocha: "^10.2.0",
          "npm-run-all": "^4.1.5",
          karma: "^6.4.2",
          "karma-chrome-launcher": "^3.2.0",
          "karma-firefox-launcher": "^2.1.2",
          "karma-mocha": "^2.0.1",
          "karma-webpack": "^5.0.0",
          nyc: "^15.1.0",
          rimraf: "^5.0.0",
          rollup: "^3.20.7",
          "wait-on": "^7.0.1",
          webpack: "^5.79.0",
          "webpack-bundle-analyzer": "^4.8.0",
          "webpack-cli": "^5.0.1",
          "webpack-dev-middleware": "^6.0.2",
          "rollup-plugin-sourcemaps": "^0.6.3"
        },
        dependencies: {
          "bmp-js": "^0.1.0",
          "idb-keyval": "^6.2.0",
          "is-url": "^1.2.4",
          "node-fetch": "^2.6.9",
          "opencollective-postinstall": "^2.0.3",
          "regenerator-runtime": "^0.13.3",
          "tesseract.js-core": "^7.0.0",
          "wasm-feature-detect": "^1.8.0",
          zlibjs: "^0.3.1"
        },
        overrides: {
          "@rollup/pluginutils": "^5.0.2"
        },
        repository: {
          type: "git",
          url: "https://github.com/naptha/tesseract.js.git"
        },
        bugs: {
          url: "https://github.com/naptha/tesseract.js/issues"
        },
        homepage: "https://github.com/naptha/tesseract.js",
        collective: {
          type: "opencollective",
          url: "https://opencollective.com/tesseractjs"
        }
      };
    }
  });

  // node_modules/tesseract.js/src/constants/defaultOptions.js
  var require_defaultOptions = __commonJS({
    "node_modules/tesseract.js/src/constants/defaultOptions.js"(exports, module) {
      "use strict";
      module.exports = {
        /*
         * Use BlobURL for worker script by default
         * TODO: remove this option
         *
         */
        workerBlobURL: true,
        logger: () => {
        }
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/defaultOptions.js
  var require_defaultOptions2 = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/defaultOptions.js"(exports, module) {
      "use strict";
      var version = require_package().version;
      var defaultOptions = require_defaultOptions();
      module.exports = {
        ...defaultOptions,
        workerPath: `https://cdn.jsdelivr.net/npm/tesseract.js@v${version}/dist/worker.min.js`
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/spawnWorker.js
  var require_spawnWorker = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/spawnWorker.js"(exports, module) {
      "use strict";
      module.exports = ({ workerPath, workerBlobURL }) => {
        let worker;
        if (Blob && URL && workerBlobURL) {
          const blob = new Blob([`importScripts("${workerPath}");`], {
            type: "application/javascript"
          });
          worker = new Worker(URL.createObjectURL(blob));
        } else {
          worker = new Worker(workerPath);
        }
        return worker;
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/terminateWorker.js
  var require_terminateWorker = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/terminateWorker.js"(exports, module) {
      "use strict";
      module.exports = (worker) => {
        worker.terminate();
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/onMessage.js
  var require_onMessage = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/onMessage.js"(exports, module) {
      "use strict";
      module.exports = (worker, handler) => {
        worker.onmessage = ({ data }) => {
          handler(data);
        };
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/send.js
  var require_send = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/send.js"(exports, module) {
      "use strict";
      module.exports = async (worker, packet) => {
        worker.postMessage(packet);
      };
    }
  });

  // node_modules/tesseract.js/src/worker/browser/loadImage.js
  var require_loadImage = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/loadImage.js"(exports, module) {
      "use strict";
      var readFromBlobOrFile = (blob) => new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.onload = () => {
          resolve(fileReader.result);
        };
        fileReader.onerror = ({ target: { error: { code } } }) => {
          reject(Error(`File could not be read! Code=${code}`));
        };
        fileReader.readAsArrayBuffer(blob);
      });
      var loadImage2 = async (image) => {
        let data = image;
        if (typeof image === "undefined") {
          return "undefined";
        }
        if (typeof image === "string") {
          if (/data:image\/([a-zA-Z]*);base64,([^"]*)/.test(image)) {
            data = atob(image.split(",")[1]).split("").map((c) => c.charCodeAt(0));
          } else {
            const resp = await fetch(image);
            data = await resp.arrayBuffer();
          }
        } else if (typeof HTMLElement !== "undefined" && image instanceof HTMLElement) {
          if (image.tagName === "IMG") {
            data = await loadImage2(image.src);
          }
          if (image.tagName === "VIDEO") {
            data = await loadImage2(image.poster);
          }
          if (image.tagName === "CANVAS") {
            await new Promise((resolve) => {
              image.toBlob(async (blob) => {
                data = await readFromBlobOrFile(blob);
                resolve();
              });
            });
          }
        } else if (typeof OffscreenCanvas !== "undefined" && image instanceof OffscreenCanvas) {
          const blob = await image.convertToBlob();
          data = await readFromBlobOrFile(blob);
        } else if (image instanceof File || image instanceof Blob) {
          data = await readFromBlobOrFile(image);
        }
        return new Uint8Array(data);
      };
      module.exports = loadImage2;
    }
  });

  // node_modules/tesseract.js/src/worker/browser/index.js
  var require_browser = __commonJS({
    "node_modules/tesseract.js/src/worker/browser/index.js"(exports, module) {
      "use strict";
      var defaultOptions = require_defaultOptions2();
      var spawnWorker = require_spawnWorker();
      var terminateWorker = require_terminateWorker();
      var onMessage = require_onMessage();
      var send = require_send();
      var loadImage2 = require_loadImage();
      module.exports = {
        defaultOptions,
        spawnWorker,
        terminateWorker,
        onMessage,
        send,
        loadImage: loadImage2
      };
    }
  });

  // node_modules/tesseract.js/src/createWorker.js
  var require_createWorker = __commonJS({
    "node_modules/tesseract.js/src/createWorker.js"(exports, module) {
      "use strict";
      var resolvePaths = require_resolvePaths();
      var createJob = require_createJob();
      var { log } = require_log();
      var getId = require_getId();
      var OEM2 = require_OEM();
      var {
        defaultOptions,
        spawnWorker,
        terminateWorker,
        onMessage,
        loadImage: loadImage2,
        send
      } = require_browser();
      var workerCounter = 0;
      module.exports = async (langs = "eng", oem = OEM2.LSTM_ONLY, _options = {}, config = {}) => {
        const id = getId("Worker", workerCounter);
        const {
          logger,
          errorHandler,
          ...options
        } = resolvePaths({
          ...defaultOptions,
          ..._options
        });
        const promises = {};
        const currentLangs = typeof langs === "string" ? langs.split("+") : langs;
        let currentOem = oem;
        let currentConfig = config;
        const lstmOnlyCore = [OEM2.DEFAULT, OEM2.LSTM_ONLY].includes(oem) && !options.legacyCore;
        let workerResReject;
        let workerResResolve;
        const workerRes = new Promise((resolve, reject) => {
          workerResResolve = resolve;
          workerResReject = reject;
        });
        const workerError = (event) => {
          workerResReject(event.message);
        };
        let worker = spawnWorker(options);
        worker.onerror = workerError;
        workerCounter += 1;
        const startJob = ({ id: jobId, action, payload }) => new Promise((resolve, reject) => {
          log(`[${id}]: Start ${jobId}, action=${action}`);
          const promiseId = `${action}-${jobId}`;
          promises[promiseId] = { resolve, reject };
          send(worker, {
            workerId: id,
            jobId,
            action,
            payload
          });
        });
        const load = () => console.warn("`load` is depreciated and should be removed from code (workers now come pre-loaded)");
        const loadInternal = (jobId) => startJob(createJob({
          id: jobId,
          action: "load",
          payload: { options: { lstmOnly: lstmOnlyCore, corePath: options.corePath, logging: options.logging } }
        }));
        const writeText = (path, text, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "writeFile", args: [path, text] }
        }));
        const readText = (path, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "readFile", args: [path, { encoding: "utf8" }] }
        }));
        const removeFile = (path, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method: "unlink", args: [path] }
        }));
        const FS = (method, args, jobId) => startJob(createJob({
          id: jobId,
          action: "FS",
          payload: { method, args }
        }));
        const loadLanguageInternal = (_langs, jobId) => startJob(createJob({
          id: jobId,
          action: "loadLanguage",
          payload: {
            langs: _langs,
            options: {
              langPath: options.langPath,
              dataPath: options.dataPath,
              cachePath: options.cachePath,
              cacheMethod: options.cacheMethod,
              gzip: options.gzip,
              lstmOnly: [OEM2.DEFAULT, OEM2.LSTM_ONLY].includes(currentOem) && !options.legacyLang
            }
          }
        }));
        const initializeInternal = (_langs, _oem, _config, jobId) => startJob(createJob({
          id: jobId,
          action: "initialize",
          payload: { langs: _langs, oem: _oem, config: _config }
        }));
        const reinitialize = (langs2 = "eng", oem2, config2, jobId) => {
          if (lstmOnlyCore && [OEM2.TESSERACT_ONLY, OEM2.TESSERACT_LSTM_COMBINED].includes(oem2)) throw Error("Legacy model requested but code missing.");
          const _oem = oem2 || currentOem;
          currentOem = _oem;
          const _config = config2 || currentConfig;
          currentConfig = _config;
          const langsArr = typeof langs2 === "string" ? langs2.split("+") : langs2;
          const _langs = langsArr.filter((x) => !currentLangs.includes(x));
          currentLangs.push(..._langs);
          if (_langs.length > 0) {
            return loadLanguageInternal(_langs, jobId).then(() => initializeInternal(langs2, _oem, _config, jobId));
          }
          return initializeInternal(langs2, _oem, _config, jobId);
        };
        const setParameters = (params = {}, jobId) => startJob(createJob({
          id: jobId,
          action: "setParameters",
          payload: { params }
        }));
        const recognize2 = async (image, opts = {}, output = {
          text: true
        }, jobId) => startJob(createJob({
          id: jobId,
          action: "recognize",
          payload: { image: await loadImage2(image), options: opts, output }
        }));
        const detect = async (image, jobId) => {
          if (lstmOnlyCore) throw Error("`worker.detect` requires Legacy model, which was not loaded.");
          return startJob(createJob({
            id: jobId,
            action: "detect",
            payload: { image: await loadImage2(image) }
          }));
        };
        const terminate = async () => {
          if (worker !== null) {
            terminateWorker(worker);
            worker = null;
          }
          return Promise.resolve();
        };
        onMessage(worker, ({
          workerId,
          jobId,
          status,
          action,
          data
        }) => {
          const promiseId = `${action}-${jobId}`;
          if (status === "resolve") {
            log(`[${workerId}]: Complete ${jobId}`);
            promises[promiseId].resolve({ jobId, data });
            delete promises[promiseId];
          } else if (status === "reject") {
            promises[promiseId].reject(data);
            delete promises[promiseId];
            if (action === "load") workerResReject(data);
            if (errorHandler) {
              errorHandler(data);
            } else {
              throw Error(data);
            }
          } else if (status === "progress") {
            logger({ ...data, userJobId: jobId });
          }
        });
        const resolveObj = {
          id,
          worker,
          load,
          writeText,
          readText,
          removeFile,
          FS,
          reinitialize,
          setParameters,
          recognize: recognize2,
          detect,
          terminate
        };
        loadInternal().then(() => loadLanguageInternal(langs)).then(() => initializeInternal(langs, oem, config)).then(() => workerResResolve(resolveObj)).catch(() => {
        });
        return workerRes;
      };
    }
  });

  // node_modules/tesseract.js/src/Tesseract.js
  var require_Tesseract = __commonJS({
    "node_modules/tesseract.js/src/Tesseract.js"(exports, module) {
      "use strict";
      var createWorker2 = require_createWorker();
      var recognize2 = async (image, langs, options) => {
        const worker = await createWorker2(langs, 1, options);
        return worker.recognize(image).finally(async () => {
          await worker.terminate();
        });
      };
      var detect = async (image, options) => {
        const worker = await createWorker2("osd", 0, options);
        return worker.detect(image).finally(async () => {
          await worker.terminate();
        });
      };
      module.exports = {
        recognize: recognize2,
        detect
      };
    }
  });

  // node_modules/tesseract.js/src/constants/languages.js
  var require_languages = __commonJS({
    "node_modules/tesseract.js/src/constants/languages.js"(exports, module) {
      "use strict";
      module.exports = {
        AFR: "afr",
        AMH: "amh",
        ARA: "ara",
        ASM: "asm",
        AZE: "aze",
        AZE_CYRL: "aze_cyrl",
        BEL: "bel",
        BEN: "ben",
        BOD: "bod",
        BOS: "bos",
        BUL: "bul",
        CAT: "cat",
        CEB: "ceb",
        CES: "ces",
        CHI_SIM: "chi_sim",
        CHI_TRA: "chi_tra",
        CHR: "chr",
        CYM: "cym",
        DAN: "dan",
        DEU: "deu",
        DZO: "dzo",
        ELL: "ell",
        ENG: "eng",
        ENM: "enm",
        EPO: "epo",
        EST: "est",
        EUS: "eus",
        FAS: "fas",
        FIN: "fin",
        FRA: "fra",
        FRK: "frk",
        FRM: "frm",
        GLE: "gle",
        GLG: "glg",
        GRC: "grc",
        GUJ: "guj",
        HAT: "hat",
        HEB: "heb",
        HIN: "hin",
        HRV: "hrv",
        HUN: "hun",
        IKU: "iku",
        IND: "ind",
        ISL: "isl",
        ITA: "ita",
        ITA_OLD: "ita_old",
        JAV: "jav",
        JPN: "jpn",
        KAN: "kan",
        KAT: "kat",
        KAT_OLD: "kat_old",
        KAZ: "kaz",
        KHM: "khm",
        KIR: "kir",
        KOR: "kor",
        KUR: "kur",
        LAO: "lao",
        LAT: "lat",
        LAV: "lav",
        LIT: "lit",
        MAL: "mal",
        MAR: "mar",
        MKD: "mkd",
        MLT: "mlt",
        MSA: "msa",
        MYA: "mya",
        NEP: "nep",
        NLD: "nld",
        NOR: "nor",
        ORI: "ori",
        PAN: "pan",
        POL: "pol",
        POR: "por",
        PUS: "pus",
        RON: "ron",
        RUS: "rus",
        SAN: "san",
        SIN: "sin",
        SLK: "slk",
        SLV: "slv",
        SPA: "spa",
        SPA_OLD: "spa_old",
        SQI: "sqi",
        SRP: "srp",
        SRP_LATN: "srp_latn",
        SWA: "swa",
        SWE: "swe",
        SYR: "syr",
        TAM: "tam",
        TEL: "tel",
        TGK: "tgk",
        TGL: "tgl",
        THA: "tha",
        TIR: "tir",
        TUR: "tur",
        UIG: "uig",
        UKR: "ukr",
        URD: "urd",
        UZB: "uzb",
        UZB_CYRL: "uzb_cyrl",
        VIE: "vie",
        YID: "yid"
      };
    }
  });

  // node_modules/tesseract.js/src/constants/PSM.js
  var require_PSM = __commonJS({
    "node_modules/tesseract.js/src/constants/PSM.js"(exports, module) {
      "use strict";
      module.exports = {
        OSD_ONLY: "0",
        AUTO_OSD: "1",
        AUTO_ONLY: "2",
        AUTO: "3",
        SINGLE_COLUMN: "4",
        SINGLE_BLOCK_VERT_TEXT: "5",
        SINGLE_BLOCK: "6",
        SINGLE_LINE: "7",
        SINGLE_WORD: "8",
        CIRCLE_WORD: "9",
        SINGLE_CHAR: "10",
        SPARSE_TEXT: "11",
        SPARSE_TEXT_OSD: "12",
        RAW_LINE: "13"
      };
    }
  });

  // node_modules/tesseract.js/src/index.js
  var require_src = __commonJS({
    "node_modules/tesseract.js/src/index.js"(exports, module) {
      "use strict";
      require_runtime();
      var createScheduler = require_createScheduler();
      var createWorker2 = require_createWorker();
      var Tesseract = require_Tesseract();
      var languages = require_languages();
      var OEM2 = require_OEM();
      var PSM2 = require_PSM();
      var { setLogging } = require_log();
      module.exports = {
        languages,
        OEM: OEM2,
        PSM: PSM2,
        createScheduler,
        createWorker: createWorker2,
        setLogging,
        ...Tesseract
      };
    }
  });

  // src/lib/geometry.js
  function normalizeRect(start, end, width, height) {
    const clamp = (value, max) => Math.max(0, Math.min(max, value));
    const x0 = clamp(Math.min(start.x, end.x), width);
    const y0 = clamp(Math.min(start.y, end.y), height);
    const x1 = clamp(Math.max(start.x, end.x), width);
    const y1 = clamp(Math.max(start.y, end.y), height);
    return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
  }
  function validateRegion(region) {
    if (!region || !["x", "y", "width", "height", "viewportWidth", "viewportHeight"].every(
      (key) => Number.isFinite(region[key])
    ))
      return false;
    return region.x >= 0 && region.y >= 0 && region.width >= 5 && region.height >= 5 && region.viewportWidth > 0 && region.viewportHeight > 0 && region.x + region.width <= region.viewportWidth + 1 && region.y + region.height <= region.viewportHeight + 1;
  }
  function pixelCrop(region, imageWidth, imageHeight) {
    if (!validateRegion(region))
      throw new Error("The selected region is invalid. Please select it again.");
    if (!(imageWidth > 0 && imageHeight > 0))
      throw new Error("Invalid screenshot dimensions.");
    const sx = imageWidth / region.viewportWidth;
    const sy = imageHeight / region.viewportHeight;
    const left = Math.max(0, Math.floor(region.x * sx));
    const top = Math.max(0, Math.floor(region.y * sy));
    const right = Math.min(imageWidth, Math.ceil((region.x + region.width) * sx));
    const bottom = Math.min(
      imageHeight,
      Math.ceil((region.y + region.height) * sy)
    );
    return { left, top, width: right - left, height: bottom - top };
  }

  // src/lib/image.js
  async function decodeImage(source2) {
    let blob = source2;
    if (typeof source2 === "string") {
      if (!source2.startsWith("data:image/"))
        throw new Error("Only local images are supported.");
      const [header, body] = source2.split(",");
      if (!header.endsWith(";base64") || !body)
        throw new Error("Invalid image data.");
      const bytes = Uint8Array.from(atob(body), (c) => c.charCodeAt(0));
      blob = new Blob([bytes], { type: header.slice(5, -7) });
    }
    if (!(blob instanceof Blob)) throw new Error("Choose an image file.");
    if (blob.size > 25 * 1024 * 1024)
      throw new Error("Choose an image smaller than 25 MB.");
    if (!/^image\/(png|jpeg|webp|bmp)$/.test(blob.type))
      throw new Error("Choose a PNG, JPEG, WebP, or BMP image.");
    let bitmap;
    try {
      bitmap = await createImageBitmap(blob);
    } catch {
      throw new Error(
        "This image could not be decoded. Try saving it as a PNG or JPEG."
      );
    }
    if (bitmap.width * bitmap.height > 4e7 || bitmap.width > 16e3 || bitmap.height > 16e3) {
      bitmap.close();
      throw new Error(
        "This image is too large. Use an image under 40 megapixels and 16,000 pixels per side."
      );
    }
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bitmap, 0, 0);
    bitmap.close();
    return canvas;
  }
  function cropCanvas(source2, region) {
    const crop = pixelCrop(region, source2.width, source2.height);
    const result2 = document.createElement("canvas");
    result2.width = crop.width;
    result2.height = crop.height;
    result2.getContext("2d").drawImage(
      source2,
      crop.left,
      crop.top,
      crop.width,
      crop.height,
      0,
      0,
      crop.width,
      crop.height
    );
    return result2;
  }
  function prepareImage(source2, { enhance = true, rotation = "0" } = {}) {
    const rotate = Number(rotation);
    const swap = rotate === 90 || rotate === 270;
    const naturalWidth = swap ? source2.height : source2.width, naturalHeight = swap ? source2.width : source2.height;
    const desiredScale = enhance && Math.max(naturalWidth, naturalHeight) < 2e3 ? 2 : 1;
    const scale = Math.min(
      desiredScale,
      Math.sqrt(16e6 / (naturalWidth * naturalHeight)),
      6e3 / Math.max(naturalWidth, naturalHeight)
    );
    const padding = 16;
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(naturalWidth * scale)) + padding * 2;
    canvas.height = Math.max(1, Math.round(naturalHeight * scale)) + padding * 2;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rotate * Math.PI / 180);
    ctx.scale(scale, scale);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(source2, -source2.width / 2, -source2.height / 2);
    ctx.restore();
    if (enhance) {
      const image = ctx.getImageData(
        padding,
        padding,
        canvas.width - padding * 2,
        canvas.height - padding * 2
      ), pixels = image.data;
      const histogram = new Uint32Array(256);
      let dark = 0;
      for (let i = 0; i < pixels.length; i += 4) {
        const value = Math.round(
          0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2]
        );
        histogram[value]++;
        if (value < 110) dark++;
      }
      const count = pixels.length / 4, invert = dark / count > 0.6;
      let low = 0, high = 255, sum = 0;
      for (let i = 0; i < 256; i++) {
        sum += histogram[i];
        if (sum > count * 0.01) {
          low = i;
          break;
        }
      }
      sum = 0;
      for (let i = 255; i >= 0; i--) {
        sum += histogram[i];
        if (sum > count * 0.01) {
          high = i;
          break;
        }
      }
      const range = high - low;
      for (let i = 0; i < pixels.length; i += 4) {
        let v = 0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2];
        if (range > 35) v = Math.max(0, Math.min(255, (v - low) * 255 / range));
        if (invert) v = 255 - v;
        pixels[i] = pixels[i + 1] = pixels[i + 2] = v;
        pixels[i + 3] = 255;
      }
      ctx.putImageData(image, padding, padding);
    }
    return canvas;
  }

  // src/lib/format.js
  var LIST = /^(?:[-*•●▪‣]|\d{1,3}[.)]|[a-zA-Z][.)])\s+/;
  var clean = (text) => String(text || "").replace(/\r\n?/g, "\n").replace(/\u00ad/g, "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  var escapeHtml = (text) => String(text).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  var median = (values) => {
    const v = values.filter((x) => Number.isFinite(x) && x > 0).sort((a, b) => a - b);
    return v.length ? v[Math.floor(v.length / 2)] : 16;
  };
  function paragraphsOf(data) {
    const paragraphs = [];
    for (const block of data.blocks || []) {
      for (const paragraph of block.paragraphs || []) {
        const lines = (paragraph.lines || []).map((line) => ({ ...line, text: clean(line.text).trim() })).filter((line) => line.text);
        if (lines.length) paragraphs.push({ lines, bbox: paragraph.bbox });
      }
    }
    if (paragraphs.length) return paragraphs;
    return clean(data.text).trim().split(/\n\s*\n/).filter(Boolean).map((text) => ({
      lines: text.split("\n").map((text2) => ({ text: text2.trim(), words: [] })).filter((line) => line.text)
    }));
  }
  function reflow(lines) {
    const result2 = [];
    for (const line of lines) {
      const text = line.text.replace(/[ \t]+/g, " ").trim();
      if (!result2.length || LIST.test(text)) result2.push(text);
      else result2[result2.length - 1] += ` ${text}`;
    }
    return result2.join("\n");
  }
  function tableRows(data) {
    const lines = paragraphsOf(data).flatMap((p) => p.lines);
    const words = lines.flatMap((l) => l.words || []).filter((w) => w.text?.trim() && w.bbox);
    if (!words.length)
      return lines.map((l) => l.text.replace(/ {2,}|\t+/g, "	"));
    const height = median(words.map((w) => w.bbox.y1 - w.bbox.y0));
    const charWidth = median(
      words.map((w) => (w.bbox.x1 - w.bbox.x0) / Math.max(1, w.text.length))
    );
    const rows = [];
    for (const word of [...words].sort(
      (a, b) => a.bbox.y0 + a.bbox.y1 - (b.bbox.y0 + b.bbox.y1)
    )) {
      const center = (word.bbox.y0 + word.bbox.y1) / 2;
      let row = rows.find((r) => Math.abs(r.center - center) < height * 0.55);
      if (!row) {
        row = { center, words: [] };
        rows.push(row);
      }
      row.words.push(word);
    }
    const cellRows = rows.map((row) => {
      const sorted = row.words.sort((a, b) => a.bbox.x0 - b.bbox.x0);
      const cells = [];
      let previous;
      for (const word of sorted) {
        if (!previous || word.bbox.x0 - previous.bbox.x1 > Math.max(charWidth * 2.7, height * 0.75))
          cells.push({ x: word.bbox.x0, text: word.text });
        else cells[cells.length - 1].text += ` ${word.text}`;
        previous = word;
      }
      return cells;
    });
    const anchors = [];
    for (const cells of cellRows)
      for (const cell of cells) {
        if (!anchors.some((x) => Math.abs(x - cell.x) <= height))
          anchors.push(cell.x);
      }
    anchors.sort((a, b) => a - b);
    return cellRows.map((cells) => {
      const row = Array(anchors.length).fill("");
      for (const cell of cells) {
        let index = 0;
        for (let i = 1; i < anchors.length; i++)
          if (Math.abs(anchors[i] - cell.x) < Math.abs(anchors[index] - cell.x))
            index = i;
        row[index] += (row[index] ? " " : "") + cell.text;
      }
      return row.join("	");
    });
  }
  function formatText(data, mode = "paragraphs") {
    if (mode === "raw") return clean(data.text).trim();
    if (mode === "table") return tableRows(data).join("\n");
    const paragraphs = paragraphsOf(data);
    if (mode === "lines")
      return paragraphs.map((p) => p.lines.map((l) => l.text).join("\n")).join("\n\n");
    const baseHeight = median(
      paragraphs.flatMap((p) => p.lines).flatMap(
        (l) => (l.words || []).map((w) => w.bbox ? w.bbox.y1 - w.bbox.y0 : 0)
      )
    );
    return paragraphs.map((p) => {
      const text = reflow(p.lines);
      if (mode !== "markdown") return text;
      const lineHeight = median(
        (p.lines[0]?.words || []).map(
          (w) => w.bbox ? w.bbox.y1 - w.bbox.y0 : 0
        )
      );
      const heading = p.lines.length === 1 && text.length < 100 && lineHeight > baseHeight * 1.4 && !LIST.test(text);
      const escaped = text.replace(/[\\`*_\[\]<>]/g, "\\$&");
      return (heading ? "## " : "") + escaped.replace(/^[•●▪‣]\s+/gm, "- ");
    }).join("\n\n");
  }
  function richHtml(text, mode) {
    const safe = escapeHtml(text);
    if (mode === "table") {
      return `<table><tbody>${safe.split("\n").map(
        (row) => `<tr>${row.split("	").map((cell) => `<td>${cell}</td>`).join("")}</tr>`
      ).join("")}</tbody></table>`;
    }
    if (mode === "lines" || mode === "raw")
      return `<pre style="white-space:pre-wrap;font-family:monospace">${safe}</pre>`;
    return safe.split(/\n\s*\n/).map((p) => {
      if (mode === "markdown" && p.startsWith("## "))
        return `<h2>${p.slice(3)}</h2>`;
      const lines = p.split("\n");
      if (lines.every((line) => /^(?:[-*•●▪‣])\s+/.test(line)))
        return `<ul>${lines.map((line) => `<li>${line.replace(/^(?:[-*•●▪‣])\s+/, "")}</li>`).join("")}</ul>`;
      if (lines.every((line) => /^\d{1,3}[.)]\s+/.test(line)))
        return `<ol start="${parseInt(lines[0], 10)}">${lines.map((line) => `<li>${line.replace(/^\d{1,3}[.)]\s+/, "")}</li>`).join("")}</ol>`;
      return `<p>${p.replace(/\n/g, "<br>")}</p>`;
    }).join("");
  }
  function spreadsheetSafe(text) {
    return text.split("\n").map(
      (row) => row.split("	").map((cell) => /^[\s]*[=+@-]/.test(cell) ? "'" + cell : cell).join("	")
    ).join("\n");
  }
  function summarize(data) {
    const words = paragraphsOf(data).flatMap((p) => p.lines).flatMap((l) => l.words || []).filter((w) => w.text?.trim());
    return {
      confidence: Math.round(Number(data.confidence) || 0),
      words: words.length || clean(data.text).trim().split(/\s+/).filter(Boolean).length,
      uncertain: words.filter((w) => w.confidence < 65).map((w) => w.text).slice(0, 30),
      paragraphs: paragraphsOf(data).length
    };
  }

  // src/lib/storage.js
  var DB_NAME = "texttap-captures";
  var MAX_AGE = 30 * 60 * 1e3;
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore("captures", { keyPath: "id" });
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function transact(mode, action) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("captures", mode);
      let result2;
      tx.oncomplete = () => {
        db.close();
        resolve(result2);
      };
      tx.onerror = tx.onabort = () => {
        db.close();
        reject(tx.error || new Error("Local capture storage failed."));
      };
      action(tx.objectStore("captures"), (value) => {
        result2 = value;
      });
    });
  }
  async function pruneCaptures(now = Date.now()) {
    return transact("readwrite", (store) => {
      const request = store.openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        if (now - cursor.value.createdAt > MAX_AGE) cursor.delete();
        cursor.continue();
      };
    });
  }
  async function takeCapture(id) {
    return transact("readwrite", (store, done) => {
      const request = store.get(id);
      request.onsuccess = () => {
        const capture = request.result;
        store.delete(id);
        done(
          capture && Date.now() - capture.createdAt <= MAX_AGE ? capture : null
        );
      };
    });
  }
  var defaultSettings = {
    segmentation: "auto",
    enhance: true,
    rotation: "0",
    format: "paragraphs"
  };
  async function getSettings() {
    if (!globalThis.chrome?.storage?.local) return { ...defaultSettings };
    const result2 = await chrome.storage.local.get("settings");
    const input = result2.settings || {};
    return {
      segmentation: ["auto", "block", "sparse", "line"].includes(
        input.segmentation
      ) ? input.segmentation : "auto",
      enhance: input.enhance !== false,
      rotation: ["0", "90", "180", "270"].includes(input.rotation) ? input.rotation : "0",
      format: ["paragraphs", "lines", "markdown", "table", "raw"].includes(
        input.format
      ) ? input.format : "paragraphs"
    };
  }
  async function saveSettings(settings2) {
    if (globalThis.chrome?.storage?.local)
      await chrome.storage.local.set({ settings: settings2 });
  }

  // src/lib/ocr.js
  var import_tesseract = __toESM(require_src(), 1);
  var MODES = {
    auto: import_tesseract.PSM.AUTO,
    block: import_tesseract.PSM.SINGLE_BLOCK,
    sparse: import_tesseract.PSM.SPARSE_TEXT,
    line: import_tesseract.PSM.SINGLE_LINE
  };
  var OcrEngine = class {
    worker = null;
    epoch = 0;
    busy = false;
    onProgress;
    rejectPending = null;
    constructor(onProgress = () => {
    }) {
      this.onProgress = onProgress;
    }
    async recognize(canvas, settings2) {
      if (this.busy) throw new Error("Recognition is already running.");
      this.busy = true;
      const epoch = ++this.epoch;
      const base = new URL(".", location.href);
      let timer;
      const cancelled = new Promise((_, reject) => {
        this.rejectPending = reject;
      });
      const work = async () => {
        const worker = await (0, import_tesseract.createWorker)("eng", import_tesseract.OEM.TESSERACT_ONLY, {
          workerPath: new URL("vendor/worker.min.js", base).href,
          corePath: new URL("vendor/core/", base).href,
          langPath: new URL("vendor/lang/", base).href.replace(/\/$/, ""),
          workerBlobURL: false,
          legacyCore: true,
          legacyLang: true,
          gzip: true,
          cacheMethod: "none",
          logger: (message) => {
            if (epoch === this.epoch) this.onProgress(message);
          },
          errorHandler: (error) => {
            if (epoch === this.epoch)
              this.rejectPending?.(
                new Error(
                  typeof error === "string" ? error : "The local OCR worker stopped unexpectedly."
                )
              );
          }
        });
        if (epoch !== this.epoch) {
          await worker.terminate();
          throw new Error("Recognition cancelled.");
        }
        this.worker = worker;
        await worker.setParameters({
          tessedit_pageseg_mode: MODES[settings2.segmentation] || import_tesseract.PSM.AUTO,
          preserve_interword_spaces: "1",
          user_defined_dpi: "300"
        });
        const { data } = await worker.recognize(
          canvas,
          {},
          { text: true, blocks: true, tsv: true }
        );
        return data;
      };
      try {
        timer = setTimeout(
          () => this.rejectPending?.(
            new Error(
              "Recognition timed out after 120 seconds. Crop a smaller area or turn off image enhancement."
            )
          ),
          12e4
        );
        return await Promise.race([work(), cancelled]);
      } finally {
        clearTimeout(timer);
        if (epoch === this.epoch) {
          this.epoch++;
          this.busy = false;
          this.rejectPending = null;
          const worker = this.worker;
          this.worker = null;
          await worker?.terminate();
        }
      }
    }
    cancel() {
      this.rejectPending?.(new Error("Recognition cancelled."));
      this.epoch++;
      this.busy = false;
      this.rejectPending = null;
      const worker = this.worker;
      this.worker = null;
      void worker?.terminate();
    }
  };

  // src/editor.js
  var $ = (id) => document.getElementById(id);
  var original = null;
  var source = null;
  var result = null;
  var busy = false;
  var edited = false;
  var cropping = false;
  var cropStart = null;
  var sourceName = "image";
  var outputFormat = "paragraphs";
  var loadSequence = 0;
  var recognitionSequence = 0;
  var engine = new OcrEngine((message) => {
    const recognizing = message.status === "recognizing text";
    $("progress-label").textContent = recognizing ? "Reading your image\u2026" : "Loading the bundled OCR engine\u2026";
    const value = Math.round((message.progress || 0) * 100);
    $("progress-value").textContent = recognizing ? `${value}%` : "";
    $("progress").value = recognizing ? value : 0;
  });
  var hints = {
    paragraphs: "Keeps paragraph breaks and lists. Joins wrapped lines without rewriting words.",
    lines: "Preserves line breaks and OCR paragraph boundaries.",
    markdown: "Adds conservative heading and list markers. Review inferred headings before using them.",
    table: "Uses word positions to infer rows and columns. Review alignment. Spreadsheet formula-like cells are escaped on copy/export.",
    raw: "The original OCR output, with no reflow or layout reconstruction."
  };
  function notice(message = "", tone = "error") {
    $("notice").textContent = message;
    $("notice").hidden = !message;
    $("notice").dataset.tone = tone;
  }
  function settings() {
    return {
      segmentation: $("segmentation").value,
      rotation: $("rotation").value,
      enhance: $("enhance").checked,
      format: outputFormat
    };
  }
  function persistSettings() {
    void saveSettings(settings()).catch(
      () => notice("Your preferences couldn\u2019t be saved. OCR will still work.", "info")
    );
  }
  function clearResult() {
    result = null;
    edited = false;
    $("output").value = "";
    $("output").disabled = true;
    $("confidence").hidden = true;
    $("result-meta").textContent = "Ready when you are";
    $("restore").disabled = true;
    updateOutput();
  }
  function updateOutput() {
    const text = $("output").value, hasText = !!text.trim();
    for (const id of ["copy", "copy-rich", "download"])
      $(id).disabled = !hasText || busy;
    $("word-count").textContent = `${text.trim() ? text.trim().split(/\s+/).length : 0} words \xB7 ${text.length} characters${edited ? " \xB7 edited" : ""}`;
    $("copy-status").textContent = "";
    $("copy").textContent = "Copy text";
    $("download").textContent = outputFormat === "markdown" ? "Save .md" : outputFormat === "table" ? "Save .tsv" : "Save .txt";
  }
  function setBusy(value) {
    busy = value;
    for (const id of [
      "new-image",
      "file-input",
      "segmentation",
      "rotation",
      "enhance",
      "sample",
      "crop-toggle",
      "format",
      "apply-crop"
    ])
      $(id).disabled = value;
    $("recognize").disabled = value || !source;
    $("reset-crop").disabled = value || source === original;
    $("recognize").textContent = value ? "Extracting\u2026" : "Extract text \u21B5";
    $("cancel").hidden = !value;
    $("progress-area").hidden = !value;
    $("restore").disabled = value || !result;
    $("output").disabled = value || !result;
    $("dropzone").setAttribute("aria-disabled", String(value));
    updateOutput();
  }
  async function confirmReplace(message = "This will replace the changes you made to the result.") {
    if (!edited) return true;
    const dialog = $("confirm-dialog");
    if (dialog.open) return false;
    $("confirm-message").textContent = message;
    dialog.returnValue = "cancel";
    dialog.showModal();
    return new Promise(
      (resolve) => dialog.addEventListener(
        "close",
        () => resolve(dialog.returnValue === "replace"),
        { once: true }
      )
    );
  }
  function renderImage() {
    const preview = $("preview");
    preview.width = source.width;
    preview.height = source.height;
    preview.getContext("2d").drawImage(source, 0, 0);
    $("dropzone").hidden = true;
    $("image-stage").hidden = false;
    $("crop-controls").hidden = false;
    $("dimensions").textContent = `${source.width.toLocaleString()} \xD7 ${source.height.toLocaleString()} px`;
    $("image-name").textContent = sourceName;
    $("image-name").title = sourceName;
    $("recognize").disabled = false;
    $("reset-crop").disabled = source === original;
  }
  function setCropMode(value) {
    cropping = value;
    cropStart = null;
    $("crop-overlay").hidden = !value;
    $("crop-fields").hidden = !value;
    $("crop-toggle").textContent = value ? "Cancel crop" : "Crop image";
    $("crop-overlay").firstElementChild.style.display = "none";
    if (value) {
      $("crop-x").value = 0;
      $("crop-y").value = 0;
      $("crop-width").value = source.width;
      $("crop-height").value = source.height;
    }
  }
  async function loadImage(image, name, region = null, autoRun = false) {
    if (busy) return;
    const sequence = ++loadSequence;
    if (!await confirmReplace(
      "Opening an image replaces your current result and edits."
    ))
      return;
    try {
      notice("Opening your image\u2026", "info");
      const decoded = await decodeImage(image);
      if (sequence !== loadSequence) return;
      original = decoded;
      source = region ? cropCanvas(decoded, region) : decoded;
      sourceName = name;
      clearResult();
      setCropMode(false);
      renderImage();
      notice();
      if (autoRun) await recognize();
    } catch (error) {
      notice(error.message);
    }
  }
  async function recognize() {
    if (busy || !source) return;
    if (!await confirmReplace(
      "Running OCR again will replace the current text and your edits."
    ))
      return;
    const sequence = ++recognitionSequence;
    notice();
    setCropMode(false);
    setBusy(true);
    $("progress").value = 0;
    $("progress-value").textContent = "";
    $("progress-label").textContent = "Preparing your image\u2026";
    try {
      await new Promise(
        (resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))
      );
      if (!busy || sequence !== recognitionSequence) return;
      const prepared = prepareImage(source, settings());
      const data = await engine.recognize(prepared, settings());
      if (sequence !== recognitionSequence) return;
      result = data;
      edited = false;
      $("output").value = formatText(data, outputFormat);
      const info = summarize(data);
      $("result-meta").textContent = `${info.confidence}% OCR confidence`;
      $("confidence").hidden = !info.uncertain.length;
      $("confidence").textContent = `Worth a second look: ${info.uncertain.join(", ")}. Confidence is the OCR engine\u2019s estimate, not a guarantee of correctness.`;
      if (!data.text?.trim())
        notice(
          "No readable text found. Crop closer, choose Single text block, rotate the image, or try without enhancement.",
          "info"
        );
      else if (info.confidence < 65)
        notice(
          "This capture has low confidence. Review the result, or crop closer and try a different layout setting.",
          "info"
        );
    } catch (error) {
      if (sequence === recognitionSequence)
        notice(
          error.message,
          error.message.includes("cancelled") ? "info" : "error"
        );
    } finally {
      if (sequence === recognitionSequence) setBusy(false);
    }
  }
  $("new-image").addEventListener("click", () => $("file-input").click());
  $("dropzone").addEventListener("click", () => {
    if (!busy) $("file-input").click();
  });
  $("dropzone").addEventListener("keydown", (event) => {
    if (["Enter", " "].includes(event.key) && !busy) {
      event.preventDefault();
      $("file-input").click();
    }
  });
  $("file-input").addEventListener("change", (event) => {
    const file = event.target.files?.[0];
    if (file) void loadImage(file, file.name);
    event.target.value = "";
  });
  document.addEventListener("dragover", (event) => {
    event.preventDefault();
    if (!busy) $("dropzone").classList.add("dragging");
  });
  document.addEventListener("dragleave", (event) => {
    if (!event.relatedTarget) $("dropzone").classList.remove("dragging");
  });
  document.addEventListener("drop", (event) => {
    event.preventDefault();
    $("dropzone").classList.remove("dragging");
    const file = event.dataTransfer.files[0];
    if (file && !busy) void loadImage(file, file.name);
  });
  document.addEventListener("paste", (event) => {
    if (event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLInputElement || busy)
      return;
    const file = Array.from(event.clipboardData.items).find((item) => item.kind === "file" && item.type.startsWith("image/"))?.getAsFile();
    if (file) {
      event.preventDefault();
      void loadImage(file, "Pasted image");
    }
  });
  $("recognize").addEventListener("click", recognize);
  $("cancel").addEventListener("click", () => {
    recognitionSequence++;
    engine.cancel();
    setBusy(false);
    notice("Recognition cancelled.", "info");
  });
  window.addEventListener("pagehide", () => engine.cancel());
  $("output").addEventListener("input", () => {
    edited = true;
    updateOutput();
  });
  $("format").addEventListener("change", async () => {
    const next = $("format").value;
    if (!await confirmReplace(
      "Switching formats will regenerate the result from the original OCR and replace your edits."
    )) {
      $("format").value = outputFormat;
      return;
    }
    outputFormat = next;
    edited = false;
    $("format-hint").textContent = hints[next];
    if (result) $("output").value = formatText(result, next);
    updateOutput();
    persistSettings();
  });
  $("restore").addEventListener("click", async () => {
    if (result && await confirmReplace()) {
      edited = false;
      $("output").value = formatText(result, outputFormat);
      updateOutput();
    }
  });
  for (const id of ["segmentation", "rotation", "enhance"])
    $(id).addEventListener("change", persistSettings);
  $("copy").addEventListener("click", async () => {
    try {
      const text = outputFormat === "table" ? spreadsheetSafe($("output").value) : $("output").value;
      await navigator.clipboard.writeText(text);
      $("copy").textContent = "Copied \u2713";
      $("copy-status").textContent = "Copied to your clipboard.";
    } catch {
      $("copy-status").textContent = "Clipboard access was blocked. Select the text and use Ctrl/Cmd+C.";
      $("output").focus();
      $("output").select();
    }
  });
  $("copy-rich").addEventListener("click", async () => {
    try {
      const text = outputFormat === "table" ? spreadsheetSafe($("output").value) : $("output").value;
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/plain": new Blob([text], { type: "text/plain" }),
          "text/html": new Blob([richHtml(text, outputFormat)], {
            type: "text/html"
          })
        })
      ]);
      $("copy-status").textContent = "Copied with formatting. Paste into a document or rich-text editor.";
    } catch {
      $("copy-status").textContent = "Rich copying is unavailable here. Use Copy text instead.";
    }
  });
  $("download").addEventListener("click", () => {
    const extension = outputFormat === "markdown" ? "md" : outputFormat === "table" ? "tsv" : "txt";
    const text = outputFormat === "table" ? spreadsheetSafe($("output").value) : $("output").value;
    const url = URL.createObjectURL(
      new Blob([text], {
        type: extension === "tsv" ? "text/tab-separated-values;charset=utf-8" : "text/plain;charset=utf-8"
      })
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `texttap-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.${extension}`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  });
  $("crop-toggle").addEventListener("click", () => {
    if (source && !busy) setCropMode(!cropping);
  });
  $("reset-crop").addEventListener("click", async () => {
    if (original && !busy && await confirmReplace("Resetting the crop clears the current result.")) {
      source = original;
      clearResult();
      setCropMode(false);
      renderImage();
    }
  });
  function cropPoint(event) {
    const rect = $("crop-overlay").getBoundingClientRect();
    return {
      x: Math.max(
        0,
        Math.min(
          source.width,
          (event.clientX - rect.left) * source.width / rect.width
        )
      ),
      y: Math.max(
        0,
        Math.min(
          source.height,
          (event.clientY - rect.top) * source.height / rect.height
        )
      )
    };
  }
  $("crop-overlay").addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    cropStart = cropPoint(event);
    event.currentTarget.setPointerCapture(event.pointerId);
  });
  $("crop-overlay").addEventListener("pointermove", (event) => {
    if (!cropStart) return;
    const rect = normalizeRect(
      cropStart,
      cropPoint(event),
      source.width,
      source.height
    );
    for (const key of ["x", "y", "width", "height"])
      $("crop-" + key).value = Math.round(rect[key]);
    const overlay = $("crop-overlay").firstElementChild;
    overlay.style.cssText = `display:block;left:${rect.x / source.width * 100}%;top:${rect.y / source.height * 100}%;width:${rect.width / source.width * 100}%;height:${rect.height / source.height * 100}%`;
  });
  $("crop-overlay").addEventListener("pointerup", () => {
    cropStart = null;
  });
  $("crop-overlay").addEventListener("pointercancel", () => {
    cropStart = null;
  });
  $("apply-crop").addEventListener("click", async () => {
    if (!source || busy || !await confirmReplace("Applying a new crop clears the current result."))
      return;
    try {
      const rect = { viewportWidth: source.width, viewportHeight: source.height };
      for (const key of ["x", "y", "width", "height"])
        rect[key] = Number($("crop-" + key).value);
      source = cropCanvas(source, rect);
      clearResult();
      setCropMode(false);
      renderImage();
      notice();
    } catch (error) {
      notice(error.message);
    }
  });
  $("sample").addEventListener("click", async () => {
    if (busy) return;
    try {
      notice("Opening the bundled sample\u2026", "info");
      const response = await fetch(new URL("sample.png", location.href));
      if (!response.ok)
        throw new Error("The bundled sample is missing. Rebuild the extension.");
      await loadImage(await response.blob(), "TextTap sample", null, true);
    } catch (error) {
      notice(error.message);
    }
  });
  document.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter" && !$("confirm-dialog").open) {
      event.preventDefault();
      void recognize();
    }
  });
  async function initialize() {
    const saved = await getSettings();
    $("segmentation").value = saved.segmentation;
    $("rotation").value = saved.rotation;
    $("enhance").checked = saved.enhance;
    outputFormat = saved.format;
    $("format").value = outputFormat;
    $("format-hint").textContent = hints[outputFormat];
    const params = new URLSearchParams(location.search), id = params.get("capture");
    if (params.has("error")) notice(params.get("error"));
    if (id) {
      const capture = await takeCapture(id);
      history.replaceState(null, "", location.pathname);
      if (!capture)
        notice(
          "This capture has expired or was already opened. Capture the source again, or choose an image."
        );
      else await loadImage(capture.image, "Screen capture", capture.region, true);
    }
    void pruneCaptures();
  }
  initialize().catch(
    (error) => notice(`Could not open your capture: ${error.message}`)
  );
})();
